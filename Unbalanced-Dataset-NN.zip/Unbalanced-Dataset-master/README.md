# Unbalanced-Dataset
Linear and non-linear methods for binary classification in case of unbalanced datasets
